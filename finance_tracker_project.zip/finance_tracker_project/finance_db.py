\
import sqlite3
from contextlib import closing
from typing import Optional, List, Tuple
import pandas as pd

DB_NAME = "finance.db"

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('savings','brokerage','mutual_fund','other')),
    institution TEXT DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tx_date TEXT NOT NULL,
    account_id INTEGER NOT NULL,
    category TEXT,
    amount REAL NOT NULL,
    notes TEXT,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS holdings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('stock','mutual_fund')),
    quantity REAL NOT NULL,
    avg_price REAL NOT NULL,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);
"""

def get_conn(db_path: str = DB_NAME):
    conn = sqlite3.connect(db_path, check_same_thread=False)
    return conn

def init_db(db_path: str = DB_NAME):
    conn = get_conn(db_path)
    with closing(conn) as c:
        c.executescript(SCHEMA)
        c.commit()

def add_account(name: str, type_: str, institution: Optional[str] = None, db_path: str = DB_NAME):
    conn = get_conn(db_path)
    with closing(conn) as c:
        c.execute("INSERT INTO accounts(name,type,institution) VALUES(?,?,?)", (name, type_, institution))
        c.commit()

def list_accounts(db_path: str = DB_NAME) -> pd.DataFrame:
    conn = get_conn(db_path)
    return pd.read_sql_query("SELECT * FROM accounts ORDER BY id", conn)

def add_transaction(tx_date: str, account_id: int, category: str, amount: float, notes: str = "", db_path: str = DB_NAME):
    conn = get_conn(db_path)
    with closing(conn) as c:
        c.execute(
            "INSERT INTO transactions(tx_date,account_id,category,amount,notes) VALUES(?,?,?,?,?)",
            (tx_date, account_id, category, amount, notes)
        )
        c.commit()

def list_transactions(db_path: str = DB_NAME) -> pd.DataFrame:
    conn = get_conn(db_path)
    return pd.read_sql_query("SELECT * FROM transactions ORDER BY tx_date DESC, id DESC", conn)

def add_holding(account_id: int, symbol: str, type_: str, quantity: float, avg_price: float, db_path: str = DB_NAME):
    conn = get_conn(db_path)
    with closing(conn) as c:
        c.execute(
            "INSERT INTO holdings(account_id,symbol,type,quantity,avg_price) VALUES(?,?,?,?,?)",
            (account_id, symbol.upper(), type_, quantity, avg_price)
        )
        c.commit()

def list_holdings(db_path: str = DB_NAME) -> pd.DataFrame:
    conn = get_conn(db_path)
    return pd.read_sql_query("SELECT * FROM holdings ORDER BY id", conn)

def account_balance_summary(db_path: str = DB_NAME) -> pd.DataFrame:
    conn = get_conn(db_path)
    df = pd.read_sql_query("""
        SELECT a.id as account_id, a.name, a.type,
               COALESCE(SUM(t.amount),0) as balance
        FROM accounts a
        LEFT JOIN transactions t ON a.id = t.account_id
        GROUP BY a.id, a.name, a.type
        ORDER BY a.id
    """, conn)
    return df
