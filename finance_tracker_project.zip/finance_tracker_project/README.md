# Personal Finance Tracker + Stock Price Prediction

A Streamlit app for tracking personal finances (savings accounts, mutual funds, other sources),
plus a simple ML-based stock price prediction module for further investment decisions.

## Features
- Track accounts (Savings, Brokerage, Mutual Fund, Other) and transactions
- Track holdings (stocks, mutual funds) and compute portfolio metrics
- Import/export CSV
- Pull historical stock prices from Yahoo Finance (via `yfinance`)
- Train a quick ML model (RandomForest) on past prices/technical features and output a short-horizon prediction
- Visual dashboards and analytics

## Quickstart

```bash
# 1) (Recommended) Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install requirements
pip install -r requirements.txt

# 3) Run the app
streamlit run app.py
```

The app will open in your browser (usually http://localhost:8501).

## Project Structure
```
finance_tracker_project/
├─ app.py
├─ finance_db.py
├─ ml_models.py
├─ utils.py
├─ requirements.txt
├─ sample_data/
│  ├─ accounts.csv
│  ├─ transactions.csv
│  └─ holdings.csv
├─ report/
│  └─ main.tex
└─ README.md
```

## Notes
- The app stores data in an SQLite database (`finance.db`) in the same folder by default.
- If `yfinance` fails (network issues/rate limits), try again later or switch to manual CSV import.
- The ML model provided is for **educational use**. It is **not** financial advice.
