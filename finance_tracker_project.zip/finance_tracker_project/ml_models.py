\
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
from dataclasses import dataclass
from typing import Dict, Any, Tuple
import yfinance as yf
from utils import rolling_features

@dataclass
class ModelResult:
    y_test: np.ndarray
    y_pred: np.ndarray
    rmse: float
    mae: float
    last_close: float
    next_pred: float

def fetch_price_history(ticker: str, period: str = "5y", interval: str = "1d") -> pd.DataFrame:
    data = yf.download(ticker, period=period, interval=interval, auto_adjust=True, progress=False)
    if data.empty:
        raise ValueError("No data received; check ticker or network.")
    data = data.rename_axis("Date").reset_index()
    return data

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.set_index("Date", inplace=True)
    feats = rolling_features(df, col="Close")
    feats = feats.dropna()
    return feats

def train_random_forest(feats: pd.DataFrame) -> Tuple[RandomForestRegressor, Dict[str, Any]]:
    X = feats.drop(columns=["target_next_close"]).values
    y = feats["target_next_close"].values
    split = int(len(feats)*0.8)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]
    model = RandomForestRegressor(n_estimators=300, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))
    mae = float(mean_absolute_error(y_test, y_pred))
    info = {"rmse": rmse, "mae": mae, "split_index": split}
    return model, info

def predict_next_close(model: RandomForestRegressor, feats: pd.DataFrame) -> float:
    last_row = feats.drop(columns=["target_next_close"]).iloc[[-1]].values
    pred = float(model.predict(last_row)[0])
    return pred

def train_and_predict(ticker: str) -> ModelResult:
    hist = fetch_price_history(ticker)
    feats = build_features(hist)
    model, info = train_random_forest(feats)
    next_pred = predict_next_close(model, feats)
    last_close = float(hist["Close"].iloc[-1])
    split = info["split_index"]
    X_test = feats.drop(columns=["target_next_close"]).values[split:]
    y_test = feats["target_next_close"].values[split:]
    y_pred = model.predict(X_test)
    rmse = info["rmse"]
    mae = info["mae"]
    return ModelResult(y_test=y_test, y_pred=y_pred, rmse=rmse, mae=mae, last_close=last_close, next_pred=next_pred)
