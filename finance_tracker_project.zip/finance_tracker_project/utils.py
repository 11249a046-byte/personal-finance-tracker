\
import pandas as pd
import numpy as np
from datetime import datetime

def clean_amount(x):
    try:
        return float(x)
    except:
        return np.nan

def to_date(d):
    if isinstance(d, (pd.Timestamp,)):
        return d.date()
    if isinstance(d, str):
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d"):
            try:
                return datetime.strptime(d, fmt).date()
            except:
                pass
    if isinstance(d, datetime):
        return d.date()
    return pd.NaT

def pct_change(series, periods=1):
    return series.pct_change(periods=periods)

def rolling_features(df, col="Close"):
    out = pd.DataFrame(index=df.index)
    out["ret_1"] = df[col].pct_change(1)
    out["ret_5"] = df[col].pct_change(5)
    out["ma_5"] = df[col].rolling(5).mean()
    out["ma_10"] = df[col].rolling(10).mean()
    out["std_5"] = df[col].rolling(5).std()
    out["std_10"] = df[col].rolling(10).std()
    out["rsi_14"] = compute_rsi(df[col], window=14)
    out["target_next_close"] = df[col].shift(-1)
    return out.dropna()

def compute_rsi(series, window=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    roll_up = up.rolling(window=window).mean()
    roll_down = down.rolling(window=window).mean()
    rs = roll_up / (roll_down + 1e-9)
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return rsi
