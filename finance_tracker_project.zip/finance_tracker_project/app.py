\
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from finance_db import init_db, add_account, list_accounts, add_transaction, list_transactions, add_holding, list_holdings, account_balance_summary
from ml_models import train_and_predict
from utils import to_date, clean_amount

st.set_page_config(page_title="Personal Finance Tracker", page_icon="💰", layout="wide")

@st.cache_resource
def _init():
    init_db()
    return True

_init()

st.title("💰 Personal Finance Tracker + 📈 Stock Predictor")

# Sidebar navigation
page = st.sidebar.radio("Navigate", ["Dashboard", "Accounts & Transactions", "Holdings", "Stock Predictor", "Import/Export"])

# ---------------- Dashboard -----------------
if page == "Dashboard":
    st.subheader("Overview")
    acc_df = account_balance_summary()
    if acc_df.empty:
        st.info("No accounts yet. Add your first account in 'Accounts & Transactions'.")
    else:
        col1, col2 = st.columns([2,2])
        with col1:
            st.write("**Account Balances**")
            st.dataframe(acc_df, use_container_width=True)
        with col2:
            st.write("**Balance by Account Type**")
            type_summary = acc_df.groupby("type")["balance"].sum().reset_index()
            fig = plt.figure()
            plt.pie(type_summary["balance"], labels=type_summary["type"], autopct="%1.1f%%")
            st.pyplot(fig)
    st.divider()
    tx = list_transactions()
    st.write("**Recent Transactions**")
    if tx.empty:
        st.caption("No transactions recorded yet.")
    else:
        st.dataframe(tx.head(25), use_container_width=True)

# ------------- Accounts & Transactions -------------
elif page == "Accounts & Transactions":
    st.subheader("Accounts")
    with st.form("add_account_form", clear_on_submit=True):
        c1, c2, c3 = st.columns(3)
        with c1:
            name = st.text_input("Account Name")
        with c2:
            type_ = st.selectbox("Type", ["savings","brokerage","mutual_fund","other"])
        with c3:
            inst = st.text_input("Institution/Bank (optional)")
        submitted = st.form_submit_button("Add Account")
        if submitted and name and type_:
            add_account(name, type_, inst or None)
            st.success("Account added.")
    st.dataframe(list_accounts(), use_container_width=True)
    st.divider()

    st.subheader("Add Transaction")
    acc_df = list_accounts()
    if acc_df.empty:
        st.warning("Please add an account first.")
    else:
        with st.form("add_tx_form", clear_on_submit=True):
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                tx_date = st.date_input("Date")
            with c2:
                account_id = st.selectbox("Account", acc_df[["id","name"]].astype(str).apply(" - ".join, axis=1).tolist())
                # parse id from "id - name"
                acc_id_parsed = int(account_id.split(" - ")[0])
            with c3:
                category = st.text_input("Category (e.g., salary, rent, groceries, SIP)")
            with c4:
                amount = st.text_input("Amount (+ income / - expense)")
            notes = st.text_input("Notes (optional)")
            submitted2 = st.form_submit_button("Add Transaction")
            if submitted2:
                amt = clean_amount(amount)
                if np.isnan(amt):
                    st.error("Invalid amount.")
                else:
                    from finance_db import add_transaction as add_tx
                    add_tx(str(tx_date), acc_id_parsed, category, float(amt), notes or "")
                    st.success("Transaction recorded.")
    st.write("**All Transactions**")
    st.dataframe(list_transactions(), use_container_width=True)

# ------------- Holdings -----------------
elif page == "Holdings":
    st.subheader("Add Holding (Stocks / Mutual Funds)")
    acc_df = list_accounts()
    if acc_df.empty:
        st.warning("Please add an account first (preferably 'brokerage' or 'mutual_fund').")
    else:
        with st.form("add_holding_form", clear_on_submit=True):
            c1, c2, c3, c4, c5 = st.columns(5)
            with c1:
                account_id = st.selectbox("Account", acc_df[["id","name"]].astype(str).apply(" - ".join, axis=1).tolist())
                acc_id_parsed = int(account_id.split(" - ")[0])
            with c2:
                symbol = st.text_input("Ticker / Symbol (e.g., AAPL, INFY.NS)")
            with c3:
                type_ = st.selectbox("Type", ["stock","mutual_fund"])
            with c4:
                quantity = st.number_input("Quantity", min_value=0.0, step=1.0, value=0.0)
            with c5:
                avg_price = st.number_input("Avg. Price", min_value=0.0, step=1.0, value=0.0)
            submitted = st.form_submit_button("Add Holding")
            if submitted and symbol and quantity>0:
                add_holding(acc_id_parsed, symbol.strip().upper(), type_, float(quantity), float(avg_price))
                st.success("Holding added.")

    st.write("**Holdings**")
    st.dataframe(list_holdings(), use_container_width=True)

# ------------- Stock Predictor -------------
elif page == "Stock Predictor":
    st.subheader("Single-step Next-Day Close Prediction (Educational)")
    ticker = st.text_input("Enter ticker (e.g., AAPL, TSLA, INFY.NS, TCS.NS)", value="AAPL")
    if st.button("Train & Predict", type="primary"):
        try:
            result = train_and_predict(ticker)
            st.success(f"Last close: {result.last_close:.2f}")
            st.info(f"Predicted next close: {result.next_pred:.2f}")
            st.caption(f"Validation RMSE: {result.rmse:.2f} | MAE: {result.mae:.2f} (lower is better)")

            # Plot actual vs predicted on validation
            fig = plt.figure()
            plt.plot(result.y_test, label="Actual")
            plt.plot(result.y_pred, label="Predicted")
            plt.title("Validation: Actual vs Predicted Next-Day Close")
            plt.legend()
            st.pyplot(fig)

            st.warning("⚠️ This is a simple model for learning purposes only, not financial advice.")
        except Exception as e:
            st.error(f"Error: {e}")

# ------------- Import / Export -------------
elif page == "Import/Export":
    st.subheader("Import CSV")
    st.caption("Upload CSVs with the following columns:")
    st.markdown("- **accounts.csv**: name,type,institution\n- **transactions.csv**: tx_date,account_id,category,amount,notes\n- **holdings.csv**: account_id,symbol,type,quantity,avg_price")

    acc_file = st.file_uploader("accounts.csv", type=["csv"])
    if acc_file is not None:
        df = pd.read_csv(acc_file)
        for _, r in df.iterrows():
            add_account(str(r["name"]), str(r["type"]), str(r.get("institution")) if not pd.isna(r.get("institution")) else None)
        st.success("Accounts imported.")

    tx_file = st.file_uploader("transactions.csv", type=["csv"])
    if tx_file is not None:
        df = pd.read_csv(tx_file)
        for _, r in df.iterrows():
            from finance_db import add_transaction as add_tx
            add_tx(str(r["tx_date"]), int(r["account_id"]), str(r.get("category","")), float(r["amount"]), str(r.get("notes","")))
        st.success("Transactions imported.")

    hold_file = st.file_uploader("holdings.csv", type=["csv"])
    if hold_file is not None:
        df = pd.read_csv(hold_file)
        for _, r in df.iterrows():
            add_holding(int(r["account_id"]), str(r["symbol"]), str(r["type"]), float(r["quantity"]), float(r["avg_price"]))
        st.success("Holdings imported.")

    st.divider()
    st.subheader("Export CSV")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.download_button("Download Accounts CSV", data=list_accounts().to_csv(index=False), file_name="accounts.csv")
    with col2:
        st.download_button("Download Transactions CSV", data=list_transactions().to_csv(index=False), file_name="transactions.csv")
    with col3:
        st.download_button("Download Holdings CSV", data=list_holdings().to_csv(index=False), file_name="holdings.csv")
